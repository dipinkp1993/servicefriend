<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;

class wholesalerController extends Controller
{
    public function index()
    {
        
       
        return view('auth.wholesalerdashboard');
      
    }
    public function managepartView()
    {
        
       
        return view('auth.managepart');
      
    }
    public function managepartAdd(Request $request)
    {
        
        DB::table('parts')->insert(
            [
            'pname'=>$request->pname,
            'pslno'=>$request->pnumber,
            'price'=>$request->price
            ]);
        return redirect()->route('viewaddedpart')
        ->with('success','Part Added successfully.');
        
      
    }
    public function viewAddedpart()
    {
        $parts = DB::table('parts')->get();
        return view("auth.viewparts",compact('parts'));
       
        
      
    }
    public function updateParts(Request $request)
    {
        
        DB::table('parts')
        ->where('pid',$request->pid)
        ->update(['pname'=>$request->pname,
        'pslno'=>$request->pnumber,
        'price'=>$request->price]);
        return redirect()->route('viewaddedpart')
        ->with('success','Part updated successfully.');
      
    }
    public function managestockView()
    {
        
        $parts = DB::table('parts')->get();
        return view('auth.managestock',compact('parts'));
      
    }
    public function managestockAdd(Request $request)
    {
        $checker= DB::table('parts_stock')
        ->where('partid',$request->pid)
        ->first();
        if (is_null($checker)) {
            
            DB::table('parts_stock')->insert(
                [
                'partid'=>$request->pid,
                'stock_quantity'=>$request->sq
                ]);
            return redirect()->route('viewaddedpart')
            ->with('success','Stock Added successfully.');
         }
         else
         {
            return redirect()->route('viewaddedpart')
            ->with('warning','Stock Already Added.Check StockList For updation');
         }
        
        
      
    }
    public function viewAddedstock()
    {
        $requests = DB::table('parts_stock')
            ->join('parts', 'parts.pid', '=', 'parts_stock.partid')
            ->select('parts.*','parts_stock.*')
            ->get();
        return view("auth.viewstocks",compact('requests'));
       
        
      
    }
    public function updateStock(Request $request)
    {
        
        DB::table('parts_stock')
        ->where('stockid',$request->stoid)
        ->update(['stock_quantity'=>$request->sq,
       ]);
        return redirect()->route('viewaddedstock')
        ->with('success','Stock updated successfully.');
      
    }
    public function partRequestswsHistoryView()
    {
        $requests = DB::table('partsrequesttows')
            ->join('servicecenters', 'servicecenters.sid', '=', 'partsrequesttows.serviid')
            ->join('parts', 'parts.pid', '=', 'partsrequesttows.parid')
            ->join('parts_stock', 'parts_stock.partid', '=', 'partsrequesttows.parid')
            ->select('partsrequesttows.*','servicecenters.*','parts.*','parts_stock.*')
            ->get();
        return view('auth.partsrequestwshistory',compact('requests'));
    }
    public function updatePartRequestsWs(Request $request)
    {
        
        DB::table('partsrequesttows')
        ->where('prwid',$request->prwid)
        ->update([
        'reqstatus'=>$request->status]);
       
        return redirect()->route('partreq')
        ->with('success','Status changed successfully.');
      
    }

}
