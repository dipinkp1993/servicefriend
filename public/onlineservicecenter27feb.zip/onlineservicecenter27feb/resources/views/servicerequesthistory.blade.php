@extends('userlayout')

    @section('content')
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Service Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Service Center</th>
                  <th>Service Date</th>
                  <th>Service Time</th>
                  <th>Vechicle Name</th>
                  <th>Vechicle Brand</th>
                  <th>Status</th>
                 
                 
              </tr>
              </thead>
              <tbody>
             
     @foreach ($requests as $request)
        <tr class="gradeX">
            
            <td>{{ ucfirst($request->centername) }}</td>
            
            <td>{{ date('d-M-Y', strtotime( $request->sdate)) }}</td>
            <td>{{ $request->stime }}</td>
            <td>{{ $request->vname }}</td>
            <td>{{ $request->vbrand }}</td>
            <td>{{ $request->request_status }}</td>
            <td><a href="" data-toggle="modal" data-target="#myModal{{ $request->rid }}">Click Here</a>
            <div class="modal" id="myModal{{ $request->rid }}">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      @foreach($histories as $history)
      @if($request->rid==$history->reqid)
      <br>
      @if($history->status=='pending')
      <div class="card bg-info text-white">
      <div class="card-body">
      Request Yet to
      </div>
      </div>
     
      
      @elseif($history->status=='approved')
      <div class="card bg-primary text-white">
      <div class="card-body"> Date:{{$history->datstatus}}
      <br>
      status:{{$history->status}}</div>
      </div>
     
     
      @elseif($history->status=='completed')
      <div class="card bg-success text-white">
      <div class="card-body"> Date:{{$history->datstatus}}
      <br>
      status:{{$history->status}}</div>
      </div>
      @endif
      @endif
      @endforeach
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div></td>

           
        </tr>
        @endforeach
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
   
    @endsection 