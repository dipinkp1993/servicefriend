@extends('userlayout')

    @section('content')
    <section>
                  <div class="card card-primary">
                      <!--<div class="card-heading navyblue"> INVOICE</div>-->
                      <div class="card-body">
                          <div class="row invoice-list">
                              <div class="col-md-12 text-center corporate-id">
                                  <h3>SERVICEFRIEND</h3>
                              </div>
                              <div class="col-lg-4 col-sm-4">
                                  <h4>BILLING ADDRESS</h4>
                                  @foreach($userdetails as $userdetail)
                                  <p>
                                     
                                      {{$userdetail->name}} 
                                      <br>
                                      {{$userdetail->address}}
                                      <br>
                                      {{$userdetail->email}}
                                      <br>
                                     
                                  </p>
                                  @endforeach
                                 
                              </div>
                              <div class="col-lg-4 col-sm-4">
                                  <h4>SHIPPING ADDRESS</h4>
                                  @foreach($requests as $request)
                                  <p>{{$request->centername}}
                                  <br>
                                  {{$request->address}}
                                      <br>
                                      {{$request->email}}
                                      <br>
                                  </p>
                                
                              </div>
                              @endforeach
                              <div class="col-lg-4 col-sm-4">
                                  <h4>INVOICE INFO</h4>
                                  @foreach($bills as $bill)
                                  <ul class="unstyled">
                                      <li>Invoice Number		: <strong>{{ $bill->cprid }}</strong></li>
                                      <li>Invoice Date		:{{ date('d-M-Y',strtotime($bill->dot)) }}</li>
                                      
                                      <li>Invoice Status		: Paid</li>
                                  </ul>
                                  @endforeach
                              </div>
                             
                          </div>
                          <table class="table table-striped table-hover">
                              <thead>
                             
                              <tr>
                                
                                  
                                  <th class="hidden-phone">Item</th>
                                  <th class="">Unit Cost</th>
                                  <th class="">Quantity</th>
                                  <th>Total</th>
                              </tr>
                              </thead>
                              <tbody>
                              @foreach($bills as $bill)
                              <tr>
                                 
                                  
                                  <td class="hidden-phone">{{ $bill->pname}}</td>
                                  <td class=""><i class="fa fa-inr" aria-hidden="true"></i>
                                   {{ $bill->price}}</td>
                                  <td class="">{{ $bill->noofparts}}</td>
                                  <td><i class="fa fa-inr" aria-hidden="true"></i>
                                  {{$bill->noofparts * $bill->price }}</td>
                              </tr>
                              @endforeach
                              </tbody>
                          </table>
                          <div class="row justify-content-end">
                              
                          </div>
                          <div class="text-center invoice-btn">
                             
                              <a class="btn btn-info text-light" onclick="javascript:window.print();"><i class="fa fa-print"></i> Print </a>
                          </div>
                      </div>
                  </div>
              </section>
    @endsection