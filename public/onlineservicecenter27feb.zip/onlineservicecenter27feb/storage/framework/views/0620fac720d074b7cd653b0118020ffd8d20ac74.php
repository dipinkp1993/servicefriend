<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thevectorlab.net/flatlab-4/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Feb 2020 09:00:54 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dipinkp ">
    <meta name="keyword" content="service center">
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Service center</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assetswebapp/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assetswebapp/css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('assetswebapp/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('assetswebapp/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assetswebapp/css/style-responsive.css')); ?>" rel="stylesheet" />


</head>

  <body>

<div class="container">
    <br>
    <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card login-wrap">
                <div class="card-header"><h2 class="form-signin-heading"><strong>- <?php echo e(__('Register')); ?> Service Center -</strong></h2></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('servicecenterregister')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Center Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>"  autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="ph" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contact Number')); ?></label>

                            <div class="col-md-6">
                                <input id="ph" type="text" class="form-control <?php if ($errors->has('ph')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ph'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="ph" value="<?php echo e(old('ph')); ?>" required autocomplete="ph" autofocus>

                                <?php if ($errors->has('ph')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ph'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>Phone Numer should be in correct Format(eg:9947123789)</strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                       
                        <div class="form-group row">
                            <label for="addr" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Address')); ?></label>

                            <div class="col-md-6">
                                <textarea id="addr" name="addr" class="form-control <?php if ($errors->has('addr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('addr'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  required autocomplete="addr" autofocus><?php echo e(old('addr')); ?></textarea>

                                <?php if ($errors->has('addr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('addr'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="licenseno" class="col-md-4 col-form-label text-md-right"><?php echo e(__('License number')); ?></label>

                            <div class="col-md-6">
                                <input id="licenseno" type="text" class="form-control <?php if ($errors->has('licenseno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('licenseno'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="licenseno" value="<?php echo e(old('licenseno')); ?>" required autocomplete="licenseno" autofocus>

                                <?php if ($errors->has('licenseno')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('licenseno'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo e(asset('assetswebapp/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assetswebapp/js/bootstrap.bundle.min.js')); ?>"></script>


  </body>

<!-- Mirrored from thevectorlab.net/flatlab-4/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Feb 2020 09:00:54 GMT -->
</html>

<?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/registersc.blade.php ENDPATH**/ ?>