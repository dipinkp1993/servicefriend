    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Parts Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Customer Name</th>
                  <th>Part Name</th>
                  <th>Number of parts</th>
                  <th>Request Status</th>
                  <th>View And Edit</th>
                 
                 
              </tr>
              </thead>
              <tbody>
             
     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="gradeX">
            
            <td><?php echo e(ucfirst($request->name)); ?></td>
            
            <td><?php echo e($request->pname); ?></td>
            <td><?php echo e($request->noofparts); ?></td>
            <td>
            <?php if($request->request_status=="paid"): ?>
            <h6 style="color:green"><i class="fa fa-check-circle" aria-hidden="true" ></i> Paid</h6>
            <?php elseif($request->request_status=="approved"): ?>
<h6 style="color:green">Approved</h6>
<?php elseif($request->request_status=="rejected"): ?>
<h6 style="color:red"><i class="fa fa-times-circle-o" aria-hidden="true" ></i> Rejected</h6>
<?php else: ?>
<h6 style="color:blue"><i class="fa fa-clock-o"  aria-hidden="true"></i> Pending</h6>

<?php endif; ?>

            
            
           </td>
            <td><a href="" data-toggle="modal" data-target="#myModal<?php echo e($request->cprid); ?>">Click Here</a>
            <div class="modal" id="myModal<?php echo e($request->cprid); ?>">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request From <?php echo e($request->name); ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <section class="card">
                          <header class="card-header">
                            <h3> Part Request Details</h3>
                          </header>
                          <div class="card-body">
                          <form method="post" action="<?php echo e(route('updatepartrequeststatus')); ?>">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="cprid"  value="<?php echo e($request->cprid); ?>">
        
        <b>     <input type="hidden" name="cid"  value="<?php echo e($request->id); ?>">                        
     <div class="form-group">
        <h6>Name : </h6>
         <h6><?php echo e($request->name); ?></h6>
       
         
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
     <h6>Part Serial Number : 
      <?php echo e($request->pslno); ?></h6>
         
        
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
        <h6> Part Name : 
        <?php echo e($request->pname); ?><h6>
         
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
         <h6>Price :
         Rs <?php echo e($request->price); ?></h6>
         
      
     </div>
     <div class="form-group">
        <h6>No Of Parts Requested :<?php echo e($request->noofparts); ?></h6>
         
      
     </div>
     <div class="form-group">
        <br>
     </div>
    
    
    
     <?php if($request->request_status=='pending'): ?>
     <div class="form-group">
         <h6>Request Status :
         <select class="form-control input-sm" name="status">
          <option value="<?php echo e($request->request_status); ?>"><?php echo e($request->request_status); ?></option>
        <option value="approved">approved</option>
        <option value="rejected">rejected</option>
        </select>
        </h6>
     </div>
     
     
     <button type="submit" class="btn btn-primary">Take Action</button>
     <?php elseif($request->request_status=="paid"): ?>
<h6 style="color:green"><i class="fa fa-check-circle" aria-hidden="true" ></i> Paid</h6>
<?php elseif($request->request_status=="rejected"): ?>
<h6 style="color:red"><i class="fa fa-times" aria-hidden="true" ></i> Rejected</h6>
     <?php else: ?>
     <div class="form-group">
         <h6 style="color:green">Request Status :
         <?php echo e($request->request_status); ?></h6>
         
     </div>
     <?php endif; ?>
 </form>
 <hr/>
 </b>


                          </div>
                      </section>
                      
      <div class="card">
      <div class="row">
    <div class="col-lg-8">
     
                              </div>

      </div>
      </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div></td>
            
           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
   
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('auth.servicelayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/partsrequesthistorysc.blade.php ENDPATH**/ ?>