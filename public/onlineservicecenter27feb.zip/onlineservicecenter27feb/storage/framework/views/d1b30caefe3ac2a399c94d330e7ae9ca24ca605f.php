    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Service Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Name of Requestee</th>
                  <th>Service Date</th>
                  <th>Service Time</th>
                  <th>Vechicle Name</th>
                  <th>Vechicle Brand</th>
                  <th colspan="2">Status</th>
                  
                  <th>View And Edit</th>
                  
                 
              </tr>
              </thead>
              <tbody>
             
     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="gradeX">
            
            <td><?php echo e(ucfirst($request->name)); ?></td>
            
            <td><?php echo e(date('d-M-Y', strtotime( $request->sdate))); ?></td>
            <td><?php echo e($request->stime); ?></td>
            <td><?php echo e($request->vname); ?></td>
            <td><?php echo e($request->vbrand); ?></td>
            <td><?php echo e($request->request_status); ?></td>
            <td>
<?php if($request->request_status=='rejected'): ?>
<i class="fa fa-times" style="color:red;" aria-hidden="true"></i>
<?php elseif($request->request_status=='completed'): ?>

<i class="fa fa-check" style="color:green;" aria-hidden="true"></i>
</a>
<?php elseif($request->request_status=='pending'): ?>
<i class="fa fa-clock-o" style="color:blue;" aria-hidden="true"></i>
<?php endif; ?>
 
</td>
            <td><a href="" data-toggle="modal" data-target="#myModal<?php echo e($request->rid); ?>">Click Here</a>
            <div class="modal" id="myModal<?php echo e($request->rid); ?>">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request From <?php echo e($request->name); ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <section class="card">
                          <header class="card-header">
                            <h3> Service Request Details</h3>
                          </header>
                          <div class="card-body">
                          <form method="post" action="<?php echo e(route('updateservicerequeststatus')); ?>">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="rid"  value="<?php echo e($request->rid); ?>">
             <input type="hidden" name="cid"  value="<?php echo e($request->id); ?>">                        
     <div class="form-group">
         <label for="exampleInputEmail1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Category : </label>
         <input type="text" disabled  name="catname" value="<?php echo e($request->catname); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Brand" value="<?php echo e(old('catname')); ?>" required autocomplete="catname" autofocus>
       
         <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?>
       <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
       </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
         <br><label for="exampleInputEmail1">Vechicle Brand : </label>
       <input type="text" name="vbrand" disabled value="<?php echo e($request->vbrand); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Brand" value="<?php echo e(old('vbrand')); ?>" required autocomplete="vbrand" autofocus>
         
         <?php if ($errors->has('vbrand')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vbrand'); ?>
       <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
       </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">Vechicle Name : </label>
         <input type="text" name="vname" value="<?php echo e($request->vname); ?>" disabled class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name" value="<?php echo e(old('vname')); ?>" required autocomplete="vname" autofocus>
         
         <?php if ($errors->has('vname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vname'); ?>
       <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
       </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">Vechicle Model : </label>
         <input type="text" name="vmodel" value="<?php echo e($request->vmodel); ?>" disabled class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Model"   autofocus>
         
         <?php if ($errors->has('vmodel')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vmodel'); ?>
       <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
       </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
         <label for="exampleInputPassword1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Date : </label>
        <input type="date" name="sdate" value="<?php echo e($request->sdate); ?>"  class="form-control" id="exampleInputPassword1"  autocomplete="sdate" autofocus>
     </div>
     <div class="form-group">
        <br>
     </div>
    
     <div class="form-group">
         <label for="exampleInputPassword1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Time : </label>
          <input type="time" name="stime" value="<?php echo e($request->stime); ?>"  class="form-control" id="exampleInputPassword1"  autocomplete="stime" autofocus>
         
     </div>
     <?php if($request->request_status=='pending'): ?>
     <div class="form-group">
         <label for="exampleInputPassword1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Request Status : </label>
         <select class="form-control input-sm" name="status">
          <option value="<?php echo e($request->request_status); ?>"><?php echo e($request->request_status); ?></option>
        <option value="approved">approved</option>
        <option value="rejected">rejected</option>
        </select>
     </div>
     
     
     <button type="submit" class="btn btn-primary">Take Action</button>
     <?php else: ?>
     <div class="form-group">
         <label for="exampleInputPassword1">&nbsp;Request Status : </label>
          <input type="text" name="status" value="<?php echo e($request->request_status); ?>"  class="form-control" disabled>
         
     </div>
     <?php endif; ?>
 </form>
 <hr/>
 
 <form method="post" action="<?php echo e(route('completeservicerequest')); ?>">
             <?php echo csrf_field(); ?>
             <?php if($request->request_status=='approved'): ?>
             <h3>Service Completion</h3>
             <input type="hidden" name="rid"  value="<?php echo e($request->rid); ?>">
             <input type="hidden" name="cid"  value="<?php echo e($request->id); ?>">                        
     <div class="form-group">
         <label for="exampleInputEmail1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Charge : </label>
         <input type="text"   name="scharge" value="" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Service charge"  required autocomplete="service charge" autofocus>
       
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Done By : </label>
         <input type="text"   name="sdoneby" value="" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Mechanic Name"  required autocomplete="service charge" autofocus>
       
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mechanic Remarks : </label>
         <input type="text"   name="remarks" value="" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Mechanic Remark"  required autocomplete="Mechanic Remark" autofocus>
       
     </div>
     <button type="submit" class="btn btn-primary">Complete Service</button>
     <?php elseif($request->request_status=='completed'): ?>
     <?php $__currentLoopData = $sdones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sdone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if($sdone->rqid==$request->rid): ?>
     <div class="form-group">
         <label for="exampleInputEmail1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Charge : </label>
         <input type="text" disabled  name="scharge" value="<?php echo e($request->service_charge); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Service charge"  required autocomplete="service charge" autofocus>
       
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">Service Done By: </label>
         <input type="text" disabled   name="sdoneby" value="<?php echo e($sdone->mname); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Mechanic Name"  required autocomplete="service charge" autofocus>
       
     </div>
     <div class="form-group">
         <label for="exampleInputEmail1">Mechanic Remark: </label>
         <input type="text" disabled   value="<?php echo e($sdone->remarks); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Mechanic Name"  required autocomplete="service charge" autofocus>
       
     </div>
     <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>

 </form>

                          </div>
                      </section>
                      
      <div class="card">
      <div class="row">
    <div class="col-lg-8">
     
                              </div>

      </div>
      </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
</td>
           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.servicelayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/userservicerequests.blade.php ENDPATH**/ ?>