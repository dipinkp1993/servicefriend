    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
               Part Request From Service Center
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Service Center</th>
                  <th>Part Number</th>
                  <th>Part Name</th>
                  <th>No of Parts Requested</th>
                  <th>Status</th>
                  <th>Action</th>
                  
                  
                 
              </tr>
              </thead>
              <tbody>
             
     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="gradeX">
            
            <td><?php echo e($request->centername); ?></td>
            <td><?php echo e($request->pslno); ?></td>
            <td><?php echo e($request->pname); ?></td>
            <td><?php echo e($request->numparts); ?></td>
            <td><?php echo e($request->reqstatus); ?></td>
            <td>
            <?php if($request->numparts>$request->stock_quantity): ?>
            <p style="color:red;">Out of Stock</p>
            <?php else: ?>
              <?php if($request->reqstatus=='pending'): ?>
              <a href="#" data-toggle="modal" data-target="#myModal<?php echo e($request->prwid); ?>">
            Click Here</a>
            <div class="modal" id="myModal<?php echo e($request->prwid); ?>">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request From <?php echo e($request->centername); ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <section class="card">
                          <header class="card-header">
                            <h3> Part Request Details</h3>
                          </header>
                          <div class="card-body">
                          <form method="post" action="<?php echo e(route('updatepartrequeststatusws')); ?>">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="prwid"  value="<?php echo e($request->prwid); ?>">
        
        <b>     <input type="hidden" name="scid"  value="<?php echo e($request->sid); ?>">                        
     <div class="form-group">
        <h6>Service Center : </h6>
         <h6><?php echo e($request->centername); ?></h6>
       
         
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
     <h6>Part Serial Number : 
      <?php echo e($request->pslno); ?></h6>
         
        
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
        <h6> Part Name : 
        <?php echo e($request->pname); ?><h6>
         
     </div>
     <div class="form-group">
        <br>
     </div>
     
     <div class="form-group">
        <h6>No Of Parts Requested :<?php echo e($request->numparts); ?></h6>
         
      
     </div>
     <div class="form-group">
        <br>
     </div>
    
    
    
     <?php if($request->reqstatus=='pending'): ?>
     <div class="form-group">
         <h6>Request Status :
         <select class="form-control input-sm" name="status">
          <option value="<?php echo e($request->reqstatus); ?>"><?php echo e($request->reqstatus); ?></option>
        <option value="approved">Approve And Allot part</option>
        <option value="rejected">Reject</option>
        </select>
        </h6>
     </div>
     
     
     <button type="submit" class="btn btn-primary">Take Action</button>
     <?php elseif($request->reqstatus=="paid"): ?>
<h6 style="color:green"><i class="fa fa-check-circle" aria-hidden="true" ></i> Paid</h6>
<?php elseif($request->reqstatus=="rejected"): ?>
<h6 style="color:red"><i class="fa fa-times" aria-hidden="true" ></i> Rejected</h6>
     <?php else: ?>
     <div class="form-group">
         <h6 style="color:green">Request Status :
         <?php echo e($request->reqstatus); ?></h6>
         
     </div>
     <?php endif; ?>
 </form>
 <hr/>
 </b>


                          </div>
                      </section>
                      
      <div class="card">
      <div class="row">
    <div class="col-lg-8">
     
                              </div>

      </div>
      </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
              <?php else: ?>
              <h6>Completed</h6>
              <?php endif; ?>
            
            <?php endif; ?>
            </td>
           
           
           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.wholesalerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/partsrequestwshistory.blade.php ENDPATH**/ ?>