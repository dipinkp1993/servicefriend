    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                View Parts
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
                                        <tr>
                                            <th>Part Serial Number</th>
                                            <th>Part Name</th>
                                            <th>Stock</th>
                                        
                                            
                                            <th>Actions</th>
                                            
                                           
                                        </tr>
                                    </thead>

                                    <tbody>
                                       <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($part->pslno); ?></td>
                                            <td><?php echo e($part->pname); ?></td>
                                            <td><?php echo e($part->stock_quantity); ?></td>
                                            <td><a href="#" data-toggle="modal" data-target="#myModal<?php echo e($part->stockid); ?>">Click Here</a>
                                            <div class="modal" id="myModal<?php echo e($part->stockid); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Edit Stock</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form class="form-horizontal form-border" method="post" action="<?php echo e(route('updatestock')); ?>">
                                   
                                    
                                   
                                     <input type="hidden" name="stoid" value="<?php echo e($part->stockid); ?>">
                                   <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Part Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" disabled name="pname" value="<?php echo e($part->pname); ?>"  class="form-control">
                                         <span class="text-danger"></span>
                                        </div>
                                       
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Part Serial Number</label>
                                        <div class="col-sm-6">
                                            <input type="text" disabled  name="pnumber" class="form-control" required  value="<?php echo e($part->pslno); ?>" >
                                        
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Stock Quantity</label>
                                        <div class="col-sm-6">
                                            <input type="text"   name="sq" class="form-control" required  value="<?php echo e($part->stock_quantity); ?>" >
                                        
                                        </div>

                                    </div>
                
                                     <div class="form-group">
                                        <label class="col-sm-3 control-label"></label>
                                        <div class="col-sm-6">
                                            <button type="submit" class="btn btn-primary">Update stock</button>
                                        </div>
                                    </div>
                                   <?php
                               
                                   ?> 
                                </form>


      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div></td>
                                               
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        
                                    </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.wholesalerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/viewstocks.blade.php ENDPATH**/ ?>