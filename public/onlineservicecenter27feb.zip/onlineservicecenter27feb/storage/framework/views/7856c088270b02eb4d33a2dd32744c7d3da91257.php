<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thevectorlab.net/flatlab-4/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Feb 2020 09:00:54 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dipinkp ">
    <meta name="keyword" content="service center">
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Service center</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assetswebapp/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assetswebapp/css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('assetswebapp/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('assetswebapp/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assetswebapp/css/style-responsive.css')); ?>" rel="stylesheet" />


</head>

  <body class="login-body">

    <div class="container">
    <?php if($message = Session::get('success')): ?>
    <br>
    <br>
        <div class="alert alert-success">
            <h3><?php echo e($message); ?></h3>
        </div>
    <?php endif; ?>

    <?php if(isset($url)): ?>
    <form method="POST" class="form-signin" action='<?php echo e(url("login/$url")); ?>' aria-label="<?php echo e(__('Login')); ?>">
    <?php else: ?>
    <form method="POST" class="form-signin" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
    <?php endif; ?>
    <?php echo csrf_field(); ?>
        <h2 class="form-signin-heading"><?php echo e(isset($url) ? ucwords($url) : ""); ?> <?php echo e(__('Login')); ?></h2>
        <div class="login-wrap">
        Email:
        <input id="email" type="email" placeholder="Email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="email" autofocus>

        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        <br>
        Password:
        <input id="password" placeholder="<?php echo e(__('Password')); ?>" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  value="<?php echo e(old('password')); ?>" name="password"  autocomplete="password" autofocus>
        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>   
         <label class="checkbox">
                <input type="checkbox"  name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me
                <span class="pull-right">
                    <a data-toggle="modal" href="#myModal"> Forgot Password?</a>

                </span>
            </label>
            <button class="btn btn-lg btn-login btn-block" type="submit"> <?php echo e(__('Login')); ?></button>
           
           
            <div class="registration">
                Don't have an account yet?
                <a class="" href="<?php echo e(route('register')); ?>">
                    Create an account
                </a>
            </div>

        </div>
      </form>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo e(asset('assetswebapp/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assetswebapp/js/bootstrap.bundle.min.js')); ?>"></script>


  </body>

<!-- Mirrored from thevectorlab.net/flatlab-4/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 Feb 2020 09:00:54 GMT -->
</html>
<?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/login.blade.php ENDPATH**/ ?>