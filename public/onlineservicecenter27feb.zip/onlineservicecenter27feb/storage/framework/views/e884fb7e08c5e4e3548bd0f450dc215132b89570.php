    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Service Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Service Center</th>
                  <th>Service Date</th>
                  <th>Service Time</th>
                  <th>Vechicle Name</th>
                  <th>Vechicle Brand</th>
                  <th>Status</th>
                 
              </tr>
              </thead>
              <tbody>
             
    
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.wholesalerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/auth/wholesalerdashboard.blade.php ENDPATH**/ ?>