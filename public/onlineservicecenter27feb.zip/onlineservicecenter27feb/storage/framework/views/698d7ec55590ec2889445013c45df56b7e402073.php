    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Service Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Service Center</th>
                  <th>Service Date</th>
                  <th>Service Time</th>
                  <th>Vechicle Name</th>
                  <th>Vechicle Brand</th>
                  <th>Status</th>
                 
                 
              </tr>
              </thead>
              <tbody>
             
     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="gradeX">
            
            <td><?php echo e(ucfirst($request->centername)); ?></td>
            
            <td><?php echo e(date('d-M-Y', strtotime( $request->sdate))); ?></td>
            <td><?php echo e($request->stime); ?></td>
            <td><?php echo e($request->vname); ?></td>
            <td><?php echo e($request->vbrand); ?></td>
            <td><?php echo e($request->request_status); ?></td>
            <td><a href="" data-toggle="modal" data-target="#myModal<?php echo e($request->rid); ?>">Click Here</a>
            <div class="modal" id="myModal<?php echo e($request->rid); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($request->rid==$history->reqid): ?>
      <br>
      <?php if($history->status=='pending'): ?>
      <div class="card bg-info text-white">
      <div class="card-body">
      Request Yet to
      </div>
      </div>
     
      
      <?php elseif($history->status=='approved'): ?>
      <div class="card bg-primary text-white">
      <div class="card-body"> Date:<?php echo e($history->datstatus); ?>

      <br>
      status:<?php echo e($history->status); ?></div>
      </div>
     
     
      <?php elseif($history->status=='completed'): ?>
      <div class="card bg-success text-white">
      <div class="card-body"> Date:<?php echo e($history->datstatus); ?>

      <br>
      status:<?php echo e($history->status); ?></div>
      </div>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div></td>

           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
   
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/servicerequesthistory.blade.php ENDPATH**/ ?>