    <?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-lg-8">
<section class="card">
    <?php if($message = Session::get('success')): ?>
    <br>
    <br>
        <div class="alert alert-success">
            <h6><?php echo e($message); ?></h6>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('danger')): ?>
    <br>
    <br>
        <div class="alert alert-danger">
            <h6><?php echo e($message); ?></h6>
        </div>
    <?php endif; ?>
                          <header class="card-header">
                              Change Password
                          </header>
                          <div class="card-body">
                              <form method="post" action="<?php echo e(route('changeuserpassword')); ?>">
                              <?php echo csrf_field(); ?>
                        
                            
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Enter Current Password</label>
                                      <input type="text" name="cp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Current Password" value="<?php echo e(old('vbrand')); ?>" required autocomplete="vbrand" autofocus>
                                     
                                    
                                  </div>
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Enter New Password</label>
                                      <input type="text" name="np" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="New Password" value="<?php echo e(old('vname')); ?>" required autocomplete="vname" autofocus>
                                     
                                     
                                  </div>
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Retype New Password</label>
                                      <input type="text" name="rnp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Retype New Password" value="<?php echo e(old('vmodel')); ?>" required autocomplete="vname" autofocus>
                                   
                                      
                                  </div>
                                 
                                  
                                  
                                  <button type="submit" class="btn btn-primary">Change Password</button>
                              </form>

                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/userchangepassword.blade.php ENDPATH**/ ?>