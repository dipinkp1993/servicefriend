    <?php $__env->startSection('content'); ?>
    <section>
                  <div class="card card-primary">
                      <!--<div class="card-heading navyblue"> INVOICE</div>-->
                      <div class="card-body">
                          <div class="row invoice-list">
                              <div class="col-md-12 text-center corporate-id">
                                  <h3>SERVICEFRIEND</h3>
                              </div>
                              <div class="col-lg-4 col-sm-4">
                                  <h4>BILLING ADDRESS</h4>
                                  <?php $__currentLoopData = $userdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p>
                                     
                                      <?php echo e($userdetail->name); ?> 
                                      <br>
                                      <?php echo e($userdetail->address); ?>

                                      <br>
                                      <?php echo e($userdetail->email); ?>

                                      <br>
                                     
                                  </p>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                              </div>
                              <div class="col-lg-4 col-sm-4">
                                  <h4>SHIPPING ADDRESS</h4>
                                  <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p><?php echo e($request->centername); ?>

                                  <br>
                                  <?php echo e($request->address); ?>

                                      <br>
                                      <?php echo e($request->email); ?>

                                      <br>
                                  </p>
                                
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-lg-4 col-sm-4">
                                  <h4>INVOICE INFO</h4>
                                  <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <ul class="unstyled">
                                      <li>Invoice Number		: <strong><?php echo e($bill->cprid); ?></strong></li>
                                      <li>Invoice Date		:<?php echo e(date('d-M-Y',strtotime($bill->dot))); ?></li>
                                      
                                      <li>Invoice Status		: Paid</li>
                                  </ul>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                             
                          </div>
                          <table class="table table-striped table-hover">
                              <thead>
                             
                              <tr>
                                
                                  
                                  <th class="hidden-phone">Item</th>
                                  <th class="">Unit Cost</th>
                                  <th class="">Quantity</th>
                                  <th>Total</th>
                              </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 
                                  
                                  <td class="hidden-phone"><?php echo e($bill->pname); ?></td>
                                  <td class=""><i class="fa fa-inr" aria-hidden="true"></i>
                                   <?php echo e($bill->price); ?></td>
                                  <td class=""><?php echo e($bill->noofparts); ?></td>
                                  <td><i class="fa fa-inr" aria-hidden="true"></i>
                                  <?php echo e($bill->noofparts * $bill->price); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                          <div class="row justify-content-end">
                              
                          </div>
                          <div class="text-center invoice-btn">
                             
                              <a class="btn btn-info text-light" onclick="javascript:window.print();"><i class="fa fa-print"></i> Print </a>
                          </div>
                      </div>
                  </div>
              </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/userpartbill.blade.php ENDPATH**/ ?>