    <?php $__env->startSection('content'); ?>
    <div class="row">
                <div class="col-sm-12">
              <section class="card">
              <header class="card-header">
                Your Parts Requests
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="card-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                  <th>Service Center</th>
                  <th>Part Name</th>
                  <th>Number of parts</th>
                  <th>Request Status</th>
                 
                 
              </tr>
              </thead>
              <tbody>
             
     <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="gradeX">
            
            <td><?php echo e(ucfirst($request->centername)); ?></td>
            
            <td><?php echo e($request->pname); ?></td>
            <td><?php echo e($request->noofparts); ?></td>
            <td><?php if($request->request_status=='approved'): ?>
         <strong style="color:green"> <?php echo e($request->request_status); ?>  </strong>/ 
           
            <a href="" class="btn btn-sm btn-outline-primary" data-toggle="modal" data-target="#myModal<?php echo e($request->cprid); ?>">Pay Amount</a>
            <div class="modal" id="myModal<?php echo e($request->cprid); ?>">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">View Payment Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <section class="card">
                          <header class="card-header">
                            <h3> Part Request Details</h3>
                          </header>
                          <div class="card-body">
                          <form method="post" action="<?php echo e(route('paypart')); ?>">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="cprid"  value="<?php echo e($request->cprid); ?>">
             <input type="hidden" name="amount"  value="<?php echo e($request->price); ?>">
             <input type="hidden" name="cprid"  value="<?php echo e($request->cprid); ?>">
             <input type="hidden" name="sid"  value="<?php echo e($request->sid); ?>">
             <input type="hidden" name="np"  value="<?php echo e($request->noofparts); ?>">
        
        <b>                            
     <div class="form-group">
        <h6>Service center : </h6>
         <h6><?php echo e($request->centername); ?></h6>
       
         
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
     <h6>Part Serial Number : 
      <?php echo e($request->pslno); ?></h6>
         
        
     </div>
     <div class="form-group">
        <br>
     </div>
     <div class="form-group">
        <h6> Part Name : 
        <?php echo e($request->pname); ?><h6>
         
     </div>
     <div class="form-group">
        <br>
     </div>
    
     <div class="form-group">
        <h6>No Of Parts Requested :<?php echo e($request->noofparts); ?></h6>
         
      
     </div>
     <div class="form-group">
         <h6 style="color:violet">Price :
         Rs <?php echo e($request->price); ?></h6>
         
      
     </div>
     <div class="form-group">
     <button type="submit" class="btn btn-primary">Pay Now</button>
     </div>
    
    
    
    
 </form>
 <hr/>
 </b>


                          </div>
                      </section>
                      
      <div class="card">
      <div class="row">
    <div class="col-lg-8">
     
                              </div>

      </div>
      </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<?php elseif($request->request_status=="paid"): ?>
<h6 style="color:green"><i class="fa fa-check-circle" aria-hidden="true" ></i> Paid | 
<a href="<?php echo e(url('home/partbill',$request->cprid)); ?>">View Bill</a></h6>
<?php elseif($request->request_status=="pending"): ?>
<h6 style="color:blue"><i class="fa fa-clock-o" aria-hidden="true" ></i> Pending
<?php else: ?>
<h6 style="color:red"><i class="fa fa-times" aria-hidden="true" ></i><?php echo e($request->request_status); ?>

<?php endif; ?>
            
            
            </td>
            
           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
              
               </tbody>
              <tfoot>
              
              </tfoot>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              
              <!-- page end-->
   
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/partsrequesthistory.blade.php ENDPATH**/ ?>