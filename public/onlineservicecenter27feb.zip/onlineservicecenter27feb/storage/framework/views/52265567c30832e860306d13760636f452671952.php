    <?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-lg-8">
                      <section class="card">
                      <?php if($message = Session::get('success')): ?>
    <br>
    <br>
        <div class="alert alert-success">
            <h3><?php echo e($message); ?></h3>
        </div>
    <?php endif; ?>
                          <header class="card-header">
                              Request Service
                          </header>
                          <div class="card-body">
                              <form method="post" action="<?php echo e(route('createservicerequest')); ?>">
                              <?php echo csrf_field(); ?>
                              <div class="form-group">
                                      <label class="">Service Center </label>
                                      <select class="form-control  js-example-basic-single" name="serviceid">
>
                                          <option value="" selected>Select a Service center</option>
                                      <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($center->sid); ?>"><?php echo e($center->centername); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         
                                         
                                      </select>
                                      
                                <?php if ($errors->has('serviceid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('serviceid'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                  <div class="form-group">
                                      <label class="">Category </label>
                                      <select class="form-control" name="catname">
                                      <option value="" selected>Select a category</option>
                                          <option value="two wheeler">Two Wheeler</option>
                                          <option value="three wheeler">Three Wheeler</option>
                                          <option value="four wheeler">Four Wheeler</option>
                                          
                                         
                                         
                                      </select>
                                      <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Vechicle Brand</label>
                                      <input type="text" name="vbrand" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Brand" value="<?php echo e(old('vbrand')); ?>" required autocomplete="vbrand" autofocus>
                                      <small id="emailHelp" class="form-text text-muted">Example(Honda,Maruti etc..)</small>
                                      <?php if ($errors->has('vbrand')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vbrand'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Vechicle Name</label>
                                      <input type="text" name="vname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name" value="<?php echo e(old('vname')); ?>" required autocomplete="vname" autofocus>
                                      <small id="emailHelp" class="form-text text-muted">Example(Yamaha Fz)</small>
                                      <?php if ($errors->has('vname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                  <div class="form-group">
                                      <label for="exampleInputEmail1">Vechicle Model</label>
                                      <input type="text" name="vmodel" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Model" value="<?php echo e(old('vmodel')); ?>" required autocomplete="vname" autofocus>
                                      <small id="emailHelp" class="form-text text-muted">Example(160cc,2015)</small>
                                      <?php if ($errors->has('vmodel')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vmodel'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                 
                                  <div class="form-group">
                                      <label for="exampleInputPassword1">Prefered Servce Date</label>
                                      <input type="date" name="sdate" class="form-control" id="exampleInputPassword1" value="<?php echo e(old('sdate')); ?>" required autocomplete="sdate" autofocus>
                                  </div>
                                  <?php if ($errors->has('sdate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sdate'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  <div class="form-group">
                                      <label for="exampleInputPassword1">Prefered Servce Time</label>
                                      <input type="time" name="stime" class="form-control" id="exampleInputPassword1" value="<?php echo e(old('stime')); ?>" required autocomplete="stime" autofocus>
                                      <?php if ($errors->has('stime')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stime'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                                  
                                  <button type="submit" class="btn btn-primary">Submit</button>
                              </form>

                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\larazone\onlineservicecenter\resources\views/servicerequest.blade.php ENDPATH**/ ?>